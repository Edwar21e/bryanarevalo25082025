/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bryanarevalo25082025.Bryanarevalo25082025;

/**
 *
 * @author bryan
 */

import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ingresar_datos();
        }
    
        public static void ingresar_datos(){
        Scanner scanner = new Scanner(System.in);
        
        int [] edades = new int[10];
        int suma = 0;
        int total_pares =0;
        int total_impares = 0;
        
        System.out.println("ingrese "+edades.length+" edades ");
        for (int i = 0; i< edades.length; i++){ 
        
        System.out.println(" edad "+i+" : ");
        edades[i] = scanner.nextInt();
        suma += edades[i];
        if ((edades[i] % 2) == 0){
           total_pares++; 
        }else{
            total_impares++;
            
        }
        }
       double promedio = (double) suma/edades.length;
       System.out.println("usted a ingresado: "+edades.length+ " edades");
       
       System.out.println("el promedio de las edades ingresadas es: "+promedio);
       
       System.out.println("ingreso: "+total_pares+" edades pares y "+total_impares+" edades impares");
       
       scanner.close();
    }
    
}
